﻿using System; /* Grading ID:S0287, Lab 1, 1/24/2020, CIS 199-02, Program code outputs typed information of hobbies, fav book and fav movie*/

namespace Lab1__1_
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Grading ID: S0287");
			Console.WriteLine("Hobbies: Video games, music listening and writing poetry");
			Console.WriteLine("Fvaorite Book: The Sun Also Rises");
			Console.WriteLine("Favorite Movie: Donnie Darko");
		}
	}
}
